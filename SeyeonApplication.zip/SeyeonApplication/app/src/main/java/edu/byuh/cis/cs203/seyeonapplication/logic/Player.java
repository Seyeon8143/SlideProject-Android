package edu.byuh.cis.cs203.seyeonapplication.logic;
public enum Player {
    X,
    O,
    BLANK,
    TIE,
}




