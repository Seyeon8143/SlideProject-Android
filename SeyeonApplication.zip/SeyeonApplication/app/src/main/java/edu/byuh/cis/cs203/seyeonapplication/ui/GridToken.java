package edu.byuh.cis.cs203.seyeonapplication.ui;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.RectF;


import edu.byuh.cis.cs203.seyeonapplication.R;
import edu.byuh.cis.cs203.seyeonapplication.logic.GameBoard;
import edu.byuh.cis.cs203.seyeonapplication.logic.Player;

public class GridToken {
    private RectF position;
    private Bitmap oImage, xImage;
    private PointF velocity;
    private int seyeon;
    int size;


    public GridToken(Resources res, int size, float x, float y) {
        oImage = BitmapFactory.decodeResource(res, R.drawable.player_o);
        oImage = Bitmap.createScaledBitmap(oImage, size, size, true);
        xImage = BitmapFactory.decodeResource(res, R.drawable.player_x);
        this.size = size;
        xImage = Bitmap.createScaledBitmap(xImage, size, size, true);
        position = new RectF(x, y, x + size, y + size);//set position of token im
        velocity = new PointF(0, 0);
        seyeon = 0;

    }


    public void move() {

        position.offset(velocity.x, velocity.y);
        seyeon ++;
        if(seyeon > 20){
            velocity.set(0,0);
            seyeon = 0;
        }
    }


    public PointF getVelocity() {
        return velocity;
    }

    public void setVelocity(PointF velocity) {
        this.velocity = velocity;

    }

    public void drawToken(Canvas c) {

            c.drawBitmap(xImage, position.left, position.top, null);
        }
        /*else
        c.drawBitmap(oImage,position.left, position.top, null);
        }*/

    }


